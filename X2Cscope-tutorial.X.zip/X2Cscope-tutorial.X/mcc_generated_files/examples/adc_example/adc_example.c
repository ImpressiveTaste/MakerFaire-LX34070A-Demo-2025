/**
 * ADC Basic Printf - Callbacks Example Driver File.
 * 
 * @file adc_example.c
 * 
 * @addtogroup adc_example
 * 
 * @brief This is the generated example implementation for ADC Basic Printf in Callbacks mode.
 *
 * @version ADC Example Driver Version 1.0.0
*/

/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

/* 1. ADC Basic Printf -> Callbacks implementation. Copy this code to your project source, e.g., to main.c  */
/* ------------------------------------------------------------------
#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/system/pins.h"
#include "mcc_generated_files/adc/{adc_header}.h" // TODO: Replace {adc_header} with the corresponding ADC header file for your project (ex: adc1.h)
#include "mcc_generated_files/timer/{timer_header}.h" // TODO: Replace {timer_header} with the corresponding timer header file for your project (ex: tmr1.h)

static struct ADC_INTERFACE *adc = &ADCx; // TODO: Replace with the ADC instance in your project

static volatile uint16_t adcResult;
static bool printResult = false;

static void ADC_ConversionDone(enum ADC_CHANNEL channel, uint16_t adcVal)
{
    if(channel == Channel_ANx) // TODO: Replace with the ADC Channel you selected in the Pin Grid View 
    {
        adcResult = adcVal; 
        printResult = true;
    }
}

static void ADC_StartConversionOnChannel(void)
{
    adc->SoftwareTriggerEnable();
}

int main(void)
{
    const struct TIMER_INTERFACE *timer = &TimerX; // TODO: Replace with the timer instance in your project

    SYSTEM_Initialize();

    adc->adcMulticoreInterface->ChannelCallbackRegister(ADC_ConversionDone);
    timer->TimeoutCallbackRegister(ADC_StartConversionOnChannel);

    while(1)
    {
        if(printResult)
        {
            (void)printf("The ADC Result is: %u\r\n",adcResult);
            IO_LED_Toggle();
            IO_Debug_Toggle();
            printResult = false;
        } 
    }    
}
------------------------------------------------------------------ */

/**
 End of File
*/